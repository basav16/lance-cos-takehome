Lance Chief of Staff take-home assignment, Basav Sharma
What's in this zip

1. lance-cos-week/
   The small Claude agent that runs my daily loop on the workbook.
   It reads the Excel file (or the live Google Sheet), ranks new asks, adds calendar blocks
   and writes drafts. It never sends anything. I read every draft and press Send myself.
   Start with README.md in that folder. Tests: python test_agent.py (16 tests, no API key needed).

2. plug-in-kits/week-plan/
   Code.gs + Dashboard.html + the template. Turns a Google Sheet into my week calendar,
   Gmail drafts and Slack messages. About 15 minutes to set up.

3. plug-in-kits/onboarding/
   Same idea for onboarding: one row per hire builds the checklist, accounts, owners and
   Day 1 schedule, and nudges owners in Slack when something is late.

The workbook (Lance_CoS_Workbook_Basav_Sharma.xlsx) is uploaded separately.
Investor numbers are my estimates from public facts and are marked with *.
